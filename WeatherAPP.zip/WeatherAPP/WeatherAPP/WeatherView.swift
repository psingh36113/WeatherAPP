//
//  WeatherView.swift
//  WeatherAPP
//
//  Created by PSingh on 5/26/23.
//

import SwiftUI
import CoreLocation

struct WeatherView: View {
    @State private var location: String = ""
    @State private var weather: Weather?

    let locationManager = CLLocationManager()
    let apiKey = "46c387da00c056042ef733ce3eb4d49c"

    var body: some View {
        VStack(alignment: .leading) {
            TextField("Enter location", text: $location, onCommit: fetchWeatherData)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
                .background(Color.red)

            if let weather = weather {
                Text("Current Temperation: \(Int(weather.main.temp))°F")
                    .font(.title)
                    .foregroundColor(.blue)
                    .padding()

                Text("Maximum Temperation:  \(Int(weather.main.temp_max))°F")
                    .font(.title)
                    .padding()

                Text("Minimum Temperation:  \(Int(weather.main.temp_min))°F")
                    .font(.title)
                    .padding()

                HStack {
                Text(weather.weather.first?.description ?? "")
                    .font(.title)
                    .padding()

                if let icon = weather.weather.first?.icon,  let iconURL = URL(string: "https://openweathermap.org/img/w/\(icon).png"),
                   let iconData = try? Data(contentsOf: iconURL),
                   let iconImage = UIImage(data: iconData) {
                    Image(uiImage: iconImage)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100, height: 100)
                }
            }
            }

            Spacer()
        }.padding(.top, 50)

        .onAppear {
            let locationDelegate = LocationDelegate(fetchWeatherData: fetchWeatherData)
            locationManager.delegate = locationDelegate
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
            fetchWeatherData()
        }
    }

    func fetchWeatherData() {
        if location.isEmpty {
            // Use current location
            guard let currentLocation = locationManager.location else {
                return
            }

            let geocoder = CLGeocoder()
            geocoder.reverseGeocodeLocation(currentLocation) { (placemarks, error) in
                if let placemark = placemarks?.first,
                   let cityName = placemark.locality ?? placemark.subAdministrativeArea ?? placemark.administrativeArea {
                    self.fetchWeatherData(cityName: cityName)
                }
            }
        } else {
            fetchWeatherData(cityName: location)
        }
    }

    func fetchWeatherData(cityName: String) {
        let urlString = "https://api.openweathermap.org/data/2.5/weather?q=\(cityName)&appid=\(apiKey)&units=imperial"
        if let url = URL(string: urlString) {
            let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                if let data = data {
                    print(String(data: data, encoding: .utf8)) // to check jason format
                    do {
                        let decoder = JSONDecoder()
                        let weather = try decoder.decode(Weather.self, from: data)
                        DispatchQueue.main.async {
                            self.weather = weather
                        }
                    } catch {
                        print("Error in parsing JSON: \(error)")
                    }
                }
            }
            task.resume()
        }
    }
}

class LocationDelegate: NSObject, CLLocationManagerDelegate {
    let fetchWeatherData: () -> Void

    init(fetchWeatherData: @escaping () -> Void) {
        self.fetchWeatherData = fetchWeatherData
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let currentLocation = locations.last else {
            return
        }

        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(currentLocation) { [weak self] (placemarks, error) in
                self?.fetchWeatherData()
                manager.stopUpdatingLocation()
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error - Location manager: \(error.localizedDescription)")
    }
}
