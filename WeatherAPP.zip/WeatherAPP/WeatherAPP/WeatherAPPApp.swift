//
//  WeatherAPPApp.swift
//  WeatherAPP
//
//  Created by PSingh on 5/26/23.
//

import SwiftUI

@main
struct WeatherAPPApp: App {
    var body: some Scene {
        WindowGroup {
            WeatherView()
        }
    }
}
